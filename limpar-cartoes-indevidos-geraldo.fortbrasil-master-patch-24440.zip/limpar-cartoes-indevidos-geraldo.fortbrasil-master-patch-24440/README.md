### Cartao Virtual Mudanca Status
<p>Script para Limpar Cartões Ativos Indevidamente</p>

### Passos:

- [x] Primeio você substitui o Arquivo CSV em: src/files
- [x] Posteriormente efetue a alteração do Script incluindo o nome do arquivo ou checa se o nome está ok, em: src/procedimento_bloquear_cartoes.py na linha 26.
- [x] Por último basta checar se o .Env está apontando para as Chaves corretas e executar o Script recém alterado.

### Execução:
<p>Este script é executado apenas uma única vez quando necessário.</p>
